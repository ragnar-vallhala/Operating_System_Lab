# Operating System Lab 4

The submission has two folders:

1. Kernel_Module
2. Proc_Module

## Kernel_Module

This directory contains the solution to the first question of creating a `Module` and later laoding and unloading it.

## Proc_Module

This directory contains the solution to the second question of creating a `Module` to create a `proc` file and removing it. The directory contains screenshots demostrating the `kernel logs` and the contents of the `proc file` after creation.

