touch executable
echo "echo 'Hello from File'">>executable
chmod +x executable
