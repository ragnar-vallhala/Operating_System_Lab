ps aux
